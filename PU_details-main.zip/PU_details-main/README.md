#This is just for fun and dose not include share any personal details

//this consists the data of students of parul university joine in year 2022

keep note that this is not the official parul university portal this is a portal driven work
